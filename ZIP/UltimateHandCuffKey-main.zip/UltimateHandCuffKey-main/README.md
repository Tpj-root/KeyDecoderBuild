# ultimatehandcuffkey
A copy of TOOOL's "Ultimate Handcuff Key" diagram from 2009

Back at DEF CON 18, TOOOL presented our formula for creating what we called the "Ultimate Handcuff Key"

By combining all of our collections, and taking exacting measurements of many models of cuffs and their keys, we were able to offer up specifications for what we felt (and still do feel) is a handcuff key that can fit in as many makes and models of cuff as possible.

This diagram image is a quick guide to help you make your own if you're interested in modifying an existing key in order to turn it into TOOOL's "Universal" handcuff key.

TOOOL held the patent on this design but that has now expired so you may see folk selling this key at retail now.  That's OK, although it would be nice if some of them would mention where they first learned of the idea.  ;-)
